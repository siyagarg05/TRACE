package Password;
import com.siyagarg.wallet.*;
import java.util.*;

//import org.cloudbus.cloudsim.examples.cloud;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Base {
	public static void main(String args[])
	{  Scanner sc=new Scanner(System.in);
		System.out.println("Choose the attack you want to simulate\n "
				+ "1. MITM Attack\n "
				+ "2. Cookie Poisoning Attack\n "
				+ "3. Crptojacking Attack\n "
				+ "4. Backdoor Attack\n "
				+ "5. Zero-day attack");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:System.out.println("Simulating MITM Attack");
		MITMCloudSim.main(args);
			break;
		case 2:System.out.println("Simulating Cookie Poisoning Attack");
		CookieCloudSim.main(args);
		break;
		case 3:System.out.println("Simulating Cryptojacking Attack");
		CloudCrypto.main(args);
		break;
		case 4:System.out.println("Simulating Backdoor Attack");
		Backdoor.main(args);
		break;
		case 5:System.out.println("Simulating Zero-day Attack");
		CryptoZeroDay.main(args);
		break;
		
		
		default:System.out.println("Invalid input");
		
		}
		
			
	}

}
