package Password;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Hack extends JDialog {

    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JLabel lbUsername;
    private JLabel lbPassword;
    private JButton btnLogin;
    private JButton btnCancel;
    private static boolean succeeded;

    public Hack(Frame parent) {
        super(parent, "Login", true);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;

        lbUsername = new JLabel("Username: ");
        cs.gridx = 0;
        cs.gridy = 0;
        cs.gridwidth = 1;
        panel.add(lbUsername, cs);

        tfUsername = new JTextField(20);
        cs.gridx = 1;
        cs.gridy = 0;
        cs.gridwidth = 2;
        panel.add(tfUsername, cs);

        lbPassword = new JLabel("Password (4+ letters/digits): ");
        cs.gridx = 0;
        cs.gridy = 1;
        cs.gridwidth = 1;
        panel.add(lbPassword, cs);

        pfPassword = new JPasswordField(20);
        cs.gridx = 1;
        cs.gridy = 1;
        cs.gridwidth = 2;
        panel.add(pfPassword, cs);

        btnLogin = new JButton("Login");
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = tfUsername.getText().trim();
                String pass = new String(pfPassword.getPassword());

                // Validate password before DB access
                if (!isValidPassword(pass)) {
                    JOptionPane.showMessageDialog(Hack.this,
                            "Password must be at least 4 characters long and contain only letters and digits.",
                            "Invalid Password",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    try (Connection connection = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
                         PreparedStatement ps = connection.prepareStatement(
                                 "INSERT INTO userinfor (username,password) VALUES (?, ?)")) {

                        ps.setString(1, username);
                        ps.setString(2, pass);
                        int rowsInserted = ps.executeUpdate();
                        System.out.println("Rows inserted: " + rowsInserted);

                    }

                    if (authenticate(username, pass)) {
                        JOptionPane.showMessageDialog(Hack.this,
                                "Hi " + getUsername() + "! You have successfully logged in.",
                                "Login",
                                JOptionPane.INFORMATION_MESSAGE);
                        succeeded = true;
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(Hack.this,
                                "Invalid username or password",
                                "Login Failed",
                                JOptionPane.ERROR_MESSAGE);
                        tfUsername.setText("");
                        pfPassword.setText("");
                        succeeded = false;
                    }

                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(Hack.this,
                            "MySQL JDBC Driver not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(Hack.this,
                            "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        JPanel bp = new JPanel();
        bp.add(btnLogin);
        bp.add(btnCancel);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    public String getUsername() {
        return tfUsername.getText().trim();
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 4) {
            return false;
        }

        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return false;
            }
        }

        return true;
    }

    public static boolean isSucceeded() {
        return succeeded;
    }

    public boolean authenticate(String username, String password) {
        // Replace this with real authentication logic
        return isValidPassword(password) && username.equalsIgnoreCase("admin") && password.equals("password123");
    }
}