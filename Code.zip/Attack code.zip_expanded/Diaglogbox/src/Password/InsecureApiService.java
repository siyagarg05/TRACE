package Password;
public class InsecureApiService {
    public String handleRequest(String username, String password) {
        // Simulate SQL injection vulnerability
        String query = "SELECT * FROM users WHERE username = '" + username + "' AND password = '" + password + "'";
        // Execute query (simulation)
        if (username.equals("admin") && password.equals("password123")) {
            return "Access granted";
        } else {
            return "Access denied";
        }
    }
}