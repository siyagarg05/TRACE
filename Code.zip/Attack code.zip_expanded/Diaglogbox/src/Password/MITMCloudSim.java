
package Password;
//package org.cloudbus.cloudsim.examples;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class MITMCloudSim {
    public static DatacenterBroker broker;
    private static List<Cloudlet> cloudletList;
    private static List<Vm> vmlist;
    private static List<Cloudlet> originalCloudletList = new ArrayList<>();
    private static List<Vm> originalVmList = new ArrayList<>();
    private static int expectedVmId; // To store the initial VM ID

    public static void main(String[] args) {
        Log.printLine("Starting CloudSimExample1...");
        Scanner scanner = new Scanner(System.in);

        try {
            int num_user = 1;
            Calendar calendar = Calendar.getInstance();
            boolean trace_flag = false;
            CloudSim.init(num_user, calendar, trace_flag);

            Datacenter datacenter0 = createDatacenter("Datacenter_0");
            broker = new DatacenterBroker("Broker");
            int brokerId = broker.getId();

            vmlist = new ArrayList<>();

            System.out.print("Enter VM ID: ");
            int vmid = scanner.nextInt();
            expectedVmId = vmid; // Store the initial VM ID

            System.out.print("Enter MIPS: ");
            int mips = scanner.nextInt();

            System.out.print("Enter Image Size (MB): ");
            long size = scanner.nextLong();

            System.out.print("Enter RAM (MB): ");
            int ram = scanner.nextInt();

            System.out.print("Enter Bandwidth: ");
            long bw = scanner.nextLong();

            System.out.print("Enter Number of CPUs: ");
            int pesNumber = scanner.nextInt();

            System.out.print("Enter VMM Name: ");
            String vmm = scanner.next();

            Vm vm = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());
            vmlist.add(vm);
            originalVmList.add(new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared()));
            broker.submitVmList(vmlist);

            cloudletList = new ArrayList<>();
            int id = 0;
            long length = 400000;
            long fileSize = 300;
            long outputSize = 300;
            UtilizationModel utilizationModel = new UtilizationModelFull();

            Cloudlet cloudlet = new Cloudlet(id, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
            cloudlet.setUserId(brokerId);
            cloudlet.setVmId(vmid);

            cloudletList.add(cloudlet);
            Cloudlet originalCloudlet = new Cloudlet(id, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
            originalCloudlet.setUserId(brokerId);
            originalCloudlet.setVmId(vmid);
            originalCloudletList.add(originalCloudlet);

            broker.submitCloudletList(cloudletList);

            saveUserInputs(vmid, mips, size, ram, bw, pesNumber, vmm);
            saveExpectedVmId(expectedVmId); // Save the expected VM ID to file

            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            List<Cloudlet> newList = broker.getCloudletReceivedList();
            mima(newList);
            displayAttackTime(newList);

            for (Cloudlet cl : newList) {
                detectMITMAttack(cl);
            }

            System.out.println("\n=== Original Values Before Attack ===");
            printCloudletList(originalCloudletList);
            printVmList(originalVmList);

            System.out.println("\n=== Values After MITM Attack ===");
            printCloudletList(newList);
            printVmList(vmlist);

            Log.printLine("CloudSimExample1 finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen");
        } finally {
            scanner.close();
        }
    }

    private static void saveExpectedVmId(int expectedVmId) {
        try {
            File directory = new File("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimData");
            if (!directory.exists()) {
                directory.mkdir();
            }

            File file = new File("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimData/expected_vm_id.txt");
            FileWriter writer = new FileWriter(file); // Overwrite the file each time
            writer.write(String.valueOf(expectedVmId));
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Datacenter createDatacenter(String name) {
        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();
        int mips = 1000;
        peList.add(new Pe(0, new PeProvisionerSimple(mips)));

        int hostId = 0;
        int ram = 2048;
        long storage = 1000000;
        int bw = 10000;

        hostList.add(
            new Host(
                hostId,
                new RamProvisionerSimple(ram),
                new BwProvisionerSimple(bw),
                storage,
                peList,
                new VmSchedulerTimeShared(peList)
            )
        );

        String arch = "x86";
        String os = "Linux";
        String vmm = "Xen";
        double time_zone = 10.0;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;
        LinkedList<Storage> storageList = new LinkedList<>();

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem,
                costPerStorage, costPerBw);

        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return datacenter;
    }

    private static void printCloudletList(List<Cloudlet> list) {
        int size = list.size();
        Cloudlet cloudlet;
        String indent = "    ";
        Log.printLine();
        Log.printLine("========== OUTPUT ==========");
        Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
                + "Data center ID" + indent + "VM ID" + indent + "Time" + indent
                + "Start Time" + indent + "Finish Time");

        DecimalFormat dft = new DecimalFormat("###.##");
        for (Cloudlet value : list) {
            cloudlet = value;
            Log.print(indent + cloudlet.getCloudletId() + indent + indent);

            if (cloudlet.getStatus() == Cloudlet.SUCCESS) {
                Log.print("SUCCESS");
                Log.printLine(indent + indent + cloudlet.getResourceId()
                        + indent + indent + indent + cloudlet.getVmId()
                        + indent + indent
                        + dft.format(cloudlet.getActualCPUTime()) + indent
                        + indent + dft.format(cloudlet.getExecStartTime())
                        + indent + indent
                        + dft.format(cloudlet.getFinishTime()));
            }
        }
    }

    private static void printVmList(List<Vm> list) {
        Log.printLine("\n========== VM DETAILS ==========");
        for (Vm vm : list) {
            Log.printLine("VM ID: " + vm.getId() + ", MIPS: " + vm.getMips() + ", RAM: " + vm.getRam() + ", BW: " + vm.getBw() + ", Size: " + vm.getSize() + ", VMM: " + vm.getVmm());
        }
    }

    private static void saveUserInputs(int vmid, int mips, long size, int ram, long bw, int pesNumber, String vmm) {
        try {
            File directory = new File("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimData");
            if (!directory.exists()) {
                directory.mkdir();
            }

            File file = new File("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimDatauser_inputs.txt");
            FileWriter writer = new FileWriter(file, true);
            writer.write("VM ID: " + vmid + "\n");
            writer.write("MIPS: " + mips + "\n");
            writer.write("Image Size (MB): " + size + "\n");
            writer.write("RAM (MB): " + ram + "\n");
            writer.write("Bandwidth: " + bw + "\n");
            writer.write("Number of CPUs: " + pesNumber + "\n");
            writer.write("VMM Name: " + vmm + "\n");
            writer.write("-----------------------------\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void mima(List<Cloudlet> list) {
        for (Cloudlet cloudlet : list) {
            Log.printLine("=== Starting Multi-Level MITM Attack on Cloudlet ID " + cloudlet.getCloudletId() + " ===");

            // Level 1 Attack: Alter VM ID
            int originalVmId = cloudlet.getVmId();
            cloudlet.setVmId(originalVmId + 1);
            Log.printLine("Level 1: VM ID changed from " + originalVmId + " ➝ " + cloudlet.getVmId());

            // Level 2 Attack: Alter Execution Start Time
            double originalStartTime = cloudlet.getExecStartTime();
            double newStartTime = originalStartTime + 10;
            cloudlet.setExecStartTime(newStartTime);
            Log.printLine("Level 2: Start Time changed from " + originalStartTime + " ➝ " + newStartTime);

            // Level 3 Attack: Simulate altered CPU time (just for display/logging, not using reflection)
            double originalCpuTime = cloudlet.getActualCPUTime();
            double fakeCpuTime = originalCpuTime + 20;
            Log.printLine("Level 3: Simulated CPU Time changed from " + originalCpuTime + " ➝ " + fakeCpuTime + " (display only)");

            Log.printLine("=== Multi-Level MITM Attack Completed on Cloudlet ID " + cloudlet.getCloudletId() + " ===\n");

        }

    }
    private static void detectMITMAttack(Cloudlet cloudlet) {
        double[] features = new double[] {
            cloudlet.getCloudletId(),
            cloudlet.getExecStartTime(),
            cloudlet.getActualCPUTime(),
            cloudlet.getFinishTime()
        };

        int currentVmId = cloudlet.getVmId();

        if (!vmlist.isEmpty()) {
            Vm originalVm = vmlist.get(0);

            String result = MLModelCaller.predictMITMAttack(
                features,
                currentVmId,
                (int) originalVm.getMips(),
                originalVm.getRam(),
                originalVm.getBw(),
                originalVm.getSize(),
                originalVm.getNumberOfPes(),
                originalVm.getVmm()
            );

            System.out.println("[Java Debug] Result from Python script: \"" + result + "\""); // ADD THIS LINE

            if (result != null && !result.isEmpty()) {
                if (result.contains("Prediction: MITM")) {
                    Log.printLine("⚠️ MITM Attack Detected for Cloudlet ID " + cloudlet.getCloudletId() +
                                  " [" + result.substring(result.indexOf("Prediction:") + "Prediction:".length()).trim() + "]");
                } else if (result.contains("Prediction: Normal")) {
                    Log.printLine("✅ No Attack Detected for Cloudlet ID " + cloudlet.getCloudletId());
                } else {
                    Log.printLine("⚠️ Unknown Prediction: " + result);
                }
            } else {
                Log.printLine("⚠️ Prediction Error: No result returned for Cloudlet ID " + cloudlet.getCloudletId());
            }
        } else {
            Log.printLine("⚠️ Error: VM list is empty, cannot perform attack detection.");
        }
    }
    private static void displayAttackTime(List<Cloudlet> list) {
        Log.printLine("\n=== Time Taken for Each MITM Attack (End Time - Start Time) ===");
        for (Cloudlet cloudlet : list) {
            double timeTaken = cloudlet.getFinishTime() - cloudlet.getExecStartTime();
            Log.printLine("Cloudlet ID " + cloudlet.getCloudletId() + " => Time Taken for Attack: " + timeTaken + " units");
        }
    }

    private static void mitigateAttack(Cloudlet cloudlet) {
        Log.printLine("Mitigating attack on Cloudlet ID " + cloudlet.getCloudletId());

        // Restore correct VM ID (you already have this line correctly)
        cloudlet.setVmId(cloudlet.getUserId()); // Assume correct VM ID = User ID

        // Reset fake values
        cloudlet.setExecStartTime(0); // Reset start time

        // Skipping actualCPUTime reflection — log instead
        Log.printLine("Note: Cannot modify actual CPU time directly in CloudSim safely.");
    }
}