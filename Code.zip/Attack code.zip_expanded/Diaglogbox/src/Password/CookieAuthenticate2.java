package Password;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CookieAuthenticate2 {
    public static void main(String arg[]) {
        demo();
        
    }
    public static void demo() {
        // Create a JFrame for the main application window
        final JFrame frame = new JFrame("JDialog Demo");
        
        // Create a login button
        final JButton btnLogin = new JButton("Click to login");

        // Add an ActionListener to handle login button clicks
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Create a LoginDialog when the button is clicked
                Cookiehack loginDlg = new Cookiehack(frame);
                loginDlg.setVisible(true);
                
                // If login is successful, update the button text to greet the user
                if (loginDlg.isSucceeded()) {
                    btnLogin.setText("Hi " + loginDlg.getUsername() + "!");
                    btnLogin.setEnabled(false); 
                    
                }
            }
        });

        // Set the properties of the main JFrame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 100);
        frame.setLayout(new FlowLayout());
        frame.getContentPane().add(btnLogin);  
        frame.setVisible(true);
    }
    public static boolean isSucceeded() {
		// TODO Auto-generated method stub
		return true;
	}
	
}