//package org.cloudbus.cloudsim.examples;
package Password;

import java.io.*;
   
public class MLModelCaller {

    public static String predictMITMAttack(double[] features, int vmId, int mips, int ram, long bw, long size, int cpus, String vmm) {
        try {
            // 1. Write all combined VM + Cloudlet features to mitm_input.csv
            FileWriter writer = new FileWriter("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimData/mitm_input.csv");
            writer.write("vm_id,mips,ram,bw,size,cpus,vmm,start_time,cpu_time,finish_time\n");
            writer.write(vmId + "," + mips + "," + ram + "," + bw + "," + size + "," + cpus + "," + vmm + ","
                         + features[1] + "," + features[2] + "," + features[3] + "\n");
            writer.close();

            // 2. Run Python prediction script
            ProcessBuilder pb = new ProcessBuilder(
            	    "C:\\Users\\Siya\\AppData\\Local\\Programs\\Python\\Python314\\python.exe",
            	    "C:\\Users\\Siya\\OneDrive - THE SHRI RAM SCHOOL\\Siya\\Ph.D\\Research Paper_2023-26\\Mitm simulation\\mitmAttackModel\\predict_mitm.py"
            	);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            // 3. Print Python script output (optional but helpful for debugging)
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("[Python] " + line);
            }

            int exitCode = process.waitFor();
            if (exitCode != 0) {
                System.out.println("Python script exited with error code: " + exitCode);
                return "Error";
            }

            // 4. Read result from mitm_result.txt
            BufferedReader resultReader = new BufferedReader(new FileReader("C:/Users/Siya/OneDrive - THE SHRI RAM SCHOOL/Siya/Ph.D/Research Paper_2023-26/Mitm simulation/CloudSimData/mitm_result.txt"));
            String result = resultReader.readLine();
            resultReader.close();

            return result != null ? result : "Error";

        } catch (Exception e) {
            e.printStackTrace();
            return "Error";
        }
    }
}