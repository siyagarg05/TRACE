package Password;

import java.text.DecimalFormat;
import java.util.*;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.*;

/**
 * Backdoor Attack Simulation 
 *
 * Scenario 1 - Normal Execution : Legitimate VMs run at full capacity.
 * Scenario 2 - Attack Scenario  : Rogue broker has stolen CPU and bandwidth.
 *                                  Legitimate VMs are left with half the MIPS
 *                                  and a quarter of the bandwidth, while the
 *                                  cloudlet queue triples due to injected tasks.
 */
public class Backdoor{

    private static List<Cloudlet> cloudletList;
    private static List<Vm>       vmlist;

    private static final int  HOST_PE_MIPS = 4000;
    private static final int  HOST_RAM_MB  = 8192;
    private static final long HOST_BW      = 20_000L;
    private static final long HOST_STORAGE = 100_000L;
    private static final int  HOST_PES     = 4;

    //Normal workload 
    private static final int  LEG_VM_COUNT  = 2;
    private static final int  LEG_MIPS      = 1000;
    private static final long LEG_BW        = 2000L;
    private static final int  LEG_RAM       = 512;
    private static final long LEG_SIZE      = 10000L;
    private static final int  LEG_PES       = 1;
    private static final int  LEG_CL_COUNT  = 4;
    private static final long LEG_CL_LENGTH = 200_000L;

    // Attack degradation factors 
    // Rogue VMs steal half the MIPS, 3/4 of bandwidth, and flood the queue
    private static final int  ATK_MIPS     = LEG_MIPS / 2;       // 500 MIPS
    private static final long ATK_BW       = LEG_BW   / 4;       // 500 BW
    private static final int  ATK_CL_COUNT = LEG_CL_COUNT * 3;   // 12 cloudlets

    //Rogue VM info 
    private static final int  ROG_VM_COUNT = 4;
    private static final int  ROG_RAM      = 1800;  // 4x1800 = 7200 MB of 8192 MB

    public static void main(String[] args) {

        printBanner("Normal Cloud Execution");
        SimulationResult normal = runSimulation(
                "Normal",
                LEG_VM_COUNT, LEG_MIPS, LEG_BW,
                LEG_CL_COUNT, LEG_CL_LENGTH,
                false, 0, 0);

        printBanner("Attack Scenario");
        SimulationResult attack = runSimulation(
                "Attack",
                LEG_VM_COUNT, ATK_MIPS, ATK_BW,
                ATK_CL_COUNT, LEG_CL_LENGTH,
                true, ROG_VM_COUNT, ROG_RAM);

        printComparativeReport(normal, attack);
    }

    
    private static SimulationResult runSimulation(
            String label,
            int vmCount, int mips, long bw,
            int clCount, long clLength,
            boolean attacked, int rogVmCount, int rogRamMb) {

        SimulationResult r = new SimulationResult(label, attacked,
                vmCount, mips, bw, clCount, clLength, rogVmCount, rogRamMb);

        try {
            CloudSim.init(1, Calendar.getInstance(), false);
            createDatacenter("DC_" + label);

            DatacenterBroker broker = createBroker("Broker_" + label);
            int brokerId = broker.getId();

            // VMs
            vmlist = new ArrayList<>();
            for (int i = 0; i < vmCount; i++) {
                vmlist.add(new Vm(i, brokerId, mips, LEG_PES,
                        LEG_RAM, bw, LEG_SIZE, "Xen",
                        new CloudletSchedulerSpaceShared()));
            }
            broker.submitVmList(vmlist);

          
            cloudletList = new ArrayList<>();
            UtilizationModel util = new UtilizationModelFull();
            for (int i = 0; i < clCount; i++) {
                Cloudlet cl = new Cloudlet(i, clLength, LEG_PES,
                        300, 300, util, util, util);
                cl.setUserId(brokerId);
                cl.setVmId(i % vmCount);
                cloudletList.add(cl);
            }
            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            collectMetrics(broker.getCloudletReceivedList(), r, vmCount, mips);

        } catch (Exception e) {
            e.printStackTrace();
        }

        printScenarioOutput(r);
        return r;
    }

    //  Metrics
   
    private static void collectMetrics(List<Cloudlet> cls, SimulationResult r,
                                       int vmCount, int mips) {
        int success = 0, failed = 0;
        double totalCpu = 0, totalWait = 0, minCpu = Double.MAX_VALUE, maxCpu = 0;
        double makespan = 0;
        Map<Integer, Double> vmLoad = new LinkedHashMap<>();

        for (Cloudlet cl : cls) {
            if (cl.getCloudletStatus() == Cloudlet.SUCCESS) {
                success++;
                double cpu  = cl.getActualCPUTime();
                double wait = cl.getExecStartTime() - cl.getSubmissionTime();
                totalCpu  += cpu;
                totalWait += wait;
                minCpu     = Math.min(minCpu, cpu);
                maxCpu     = Math.max(maxCpu, cpu);
                makespan   = Math.max(makespan, cl.getFinishTime());
                vmLoad.merge(cl.getVmId(), cpu, Double::sum);
            } else {
                failed++;
            }
        }

        r.successCount = success;
        r.failedCount  = failed;
        r.avgCpuTime   = success > 0 ? totalCpu  / success : 0;
        r.avgWaitTime  = success > 0 ? totalWait / success : 0;
        r.minCpuTime   = minCpu == Double.MAX_VALUE ? 0 : minCpu;
        r.maxCpuTime   = maxCpu;
        r.makespan     = makespan;
        r.throughput   = (success > 0 && makespan > 0) ? success / makespan : 0;
        r.vmLoad       = vmLoad;

       
        double availableMips = (double) vmCount * mips;
        r.cpuUtilPct = availableMips > 0 && makespan > 0
                ? Math.min(100.0, (totalCpu * mips / (availableMips * makespan)) * 100)
                : 0;

        r.exhaustionRatio = r.rogVmCount > 0
                ? Math.min(1.0, (double)(r.rogVmCount * r.rogRamMb) / HOST_RAM_MB)
                : 0.0;
    }


    private static void printScenarioOutput(SimulationResult r) {
        DecimalFormat df  = new DecimalFormat("###.##");
        DecimalFormat pct = new DecimalFormat("###.##'%'");

        System.out.println("\nScenario : " + r.label);
        System.out.println("Status   : " + (r.attacked ? "Under Attack" : "Normal Operation"));

        System.out.println("\n--- Workload ---");
        System.out.println("VMs              : " + r.vmCount);
        System.out.println("MIPS per VM      : " + r.mips);
        System.out.println("Bandwidth per VM : " + r.bw);
        System.out.println("Cloudlets sent   : " + r.clCount);
        System.out.println("Successful       : " + r.successCount);
        System.out.println("Failed           : " + r.failedCount);

        System.out.println("\n--- Performance ---");
        System.out.println("Makespan (s)     : " + df.format(r.makespan));
        System.out.println("Avg CPU time (s) : " + df.format(r.avgCpuTime));
        System.out.println("Min CPU time (s) : " + df.format(r.minCpuTime));
        System.out.println("Max CPU time (s) : " + df.format(r.maxCpuTime));
        System.out.println("Avg wait time(s) : " + df.format(r.avgWaitTime));
        System.out.println("Throughput(cl/s) : " + df.format(r.throughput));
        System.out.println("CPU util %       : " + pct.format(r.cpuUtilPct));

        if (r.attacked) {
            System.out.println("\n--- Attack Info ---");
            System.out.println("Rogue VMs        : " + r.rogVmCount);
            System.out.println("RAM stolen       : " + (r.rogVmCount * r.rogRamMb) + " MB of " + HOST_RAM_MB + " MB");
            System.out.println("RAM exhaustion   : " + pct.format(r.exhaustionRatio * 100));
        }

        if (!r.vmLoad.isEmpty()) {
            System.out.println("\n--- Per-VM Load ---");
            for (Map.Entry<Integer, Double> e : r.vmLoad.entrySet()) {
                System.out.println("VM " + e.getKey() + " : " + new DecimalFormat("###.##").format(e.getValue()) + " s");
            }
        }
    }

    private static void printComparativeReport(SimulationResult n, SimulationResult a) {
        DecimalFormat df  = new DecimalFormat("###.##");
        DecimalFormat pct = new DecimalFormat("###.##'%'");

        System.out.println("\n---Comparative Summary ---");
        System.out.printf("%-22s  %-15s  %-15s%n", "Metric", "Normal", "Under Attack");
        System.out.println();
        System.out.printf("%-22s  %-15s  %-15s%n", "VMs",             n.vmCount,               a.vmCount);
        System.out.printf("%-22s  %-15s  %-15s%n", "MIPS per VM",     n.mips,                  a.mips);
        System.out.printf("%-22s  %-15s  %-15s%n", "Bandwidth",       n.bw,                    a.bw);
        System.out.printf("%-22s  %-15s  %-15s%n", "Cloudlets",       n.clCount,               a.clCount);
        System.out.printf("%-22s  %-15s  %-15s%n", "Successful",      n.successCount,          a.successCount);
        System.out.printf("%-22s  %-15s  %-15s%n", "Failed",          n.failedCount,           a.failedCount);
        System.out.printf("%-22s  %-15s  %-15s%n", "Makespan (s)",    df.format(n.makespan),   df.format(a.makespan));
        System.out.printf("%-22s  %-15s  %-15s%n", "Avg CPU time (s)",df.format(n.avgCpuTime), df.format(a.avgCpuTime));
        System.out.printf("%-22s  %-15s  %-15s%n", "Avg wait time(s)",df.format(n.avgWaitTime),df.format(a.avgWaitTime));
        System.out.printf("%-22s  %-15s  %-15s%n", "Throughput(cl/s)",df.format(n.throughput), df.format(a.throughput));
        System.out.printf("%-22s  %-15s  %-15s%n", "CPU utilisation %",      pct.format(n.cpuUtilPct),pct.format(a.cpuUtilPct));
        System.out.printf("%-22s  %-15s  %-15s%n", "RAM exhaustion",  "0%",                    pct.format(a.exhaustionRatio * 100));
    }

    private static void printBanner(String title) {
        System.out.println("\n" + title);
        //System.out.println("----------------------------------------------------");
    }

    private static Datacenter createDatacenter(String name) {
        List<Pe>   peList   = new ArrayList<>();
        List<Host> hostList = new ArrayList<>();

        for (int i = 0; i < HOST_PES; i++)
            peList.add(new Pe(i, new PeProvisionerSimple(HOST_PE_MIPS)));

        hostList.add(new Host(
                0,
                new RamProvisionerSimple(HOST_RAM_MB),
                new BwProvisionerSimple(HOST_BW),
                HOST_STORAGE,
                peList,
                new VmSchedulerSpaceShared(peList)
        ));

        DatacenterCharacteristics chars = new DatacenterCharacteristics(
                "x86", "Linux", "Xen", hostList,
                10.0, 3.0, 0.05, 0.001, 0.0);
        try {
            return new Datacenter(name, chars,
                    new VmAllocationPolicySimple(hostList),
                    new LinkedList<>(), 0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static DatacenterBroker createBroker(String name) {
        try {
            return new DatacenterBroker(name);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

   
    static class SimulationResult {
        String  label;
        boolean attacked;
        int     vmCount, mips, clCount, rogVmCount, rogRamMb;
        long    bw, clLength;
        int     successCount, failedCount;
        double  avgCpuTime, avgWaitTime, minCpuTime, maxCpuTime;
        double  makespan, throughput, cpuUtilPct, exhaustionRatio;
        Map<Integer, Double> vmLoad = new LinkedHashMap<>();

        SimulationResult(String label, boolean attacked,
                         int vmCount, int mips, long bw,
                         int clCount, long clLength,
                         int rogVmCount, int rogRamMb) {
            this.label      = label;
            this.attacked   = attacked;
            this.vmCount    = vmCount;
            this.mips       = mips;
            this.bw         = bw;
            this.clCount    = clCount;
            this.clLength   = clLength;
            this.rogVmCount = rogVmCount;
            this.rogRamMb   = rogRamMb;
        }
    }
}