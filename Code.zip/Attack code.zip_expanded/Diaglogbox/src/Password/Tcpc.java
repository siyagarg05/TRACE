package Password;
import java.net.*;
import java.io.*;
class Tcpc
{
 public static void main(String args[])
 {long attackStart = System.nanoTime();
 
 
 Socket s;
 try
 {
  s=new Socket("127.0.0.1",8888);
  System.out.println("Establishing the connection");
  InputStream is=s.getInputStream();
  DataInputStream dis=new DataInputStream(is);
  String str1=(String)dis.readUTF();
  System.out.println(str1);
  dis.close();
  is.close();
 }catch(Exception e)
 {
  System.out.println("Error2"); 
 }
 long attackEnd = System.nanoTime();
 System.out.printf("Attack time: %.3f ms\n", (attackEnd - attackStart) / 1000000.0);
}
}