


package Password;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class SQLInjection extends JDialog {

    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JLabel lbUsername;
    private JLabel lbPassword;
    private JButton btnLogin;
    private JButton btnRegister;
    private JButton btnCancel;
    private static boolean succeeded;

    public SQLInjection(Frame parent) {
        super(parent, "Login / Register", true);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;

        lbUsername = new JLabel("Username: ");
        cs.gridx = 0;
        cs.gridy = 0;
        cs.gridwidth = 1;
        panel.add(lbUsername, cs);

        tfUsername = new JTextField(20);
        cs.gridx = 1;
        cs.gridy = 0;
        cs.gridwidth = 2;
        panel.add(tfUsername, cs);

        lbPassword = new JLabel("Password: ");
        cs.gridx = 0;
        cs.gridy = 1;
        cs.gridwidth = 1;
        panel.add(lbPassword, cs);

        pfPassword = new JPasswordField(20);
        cs.gridx = 1;
        cs.gridy = 1;
        cs.gridwidth = 2;
        panel.add(pfPassword, cs);

        panel.setBorder(BorderFactory.createTitledBorder("Login Panel"));

        btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (authenticate(username, password)) {
                JOptionPane.showMessageDialog(SQLInjection.this,
                        "Hi " + username + "! You have successfully logged in.",
                        "Login", JOptionPane.INFORMATION_MESSAGE);
                succeeded = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(SQLInjection.this,
                        "Invalid username or password",
                        "Login Failed", JOptionPane.ERROR_MESSAGE);
                tfUsername.setText("");
                pfPassword.setText("");
                succeeded = false;
            }
        });

        btnRegister = new JButton("Register");
        btnRegister.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (!isValidPassword(password)) {
                JOptionPane.showMessageDialog(SQLInjection.this,
                        "Password must be at least 4 characters with only letters and digits.",
                        "Invalid Password", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (register(username, password)) {
                JOptionPane.showMessageDialog(SQLInjection.this,
                        "Registration successful! You can now login.",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(SQLInjection.this,
                        "Username already exists or registration failed.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());

        JPanel bp = new JPanel();
        bp.add(btnLogin);
        bp.add(btnRegister);
        bp.add(btnCancel);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    public String getUsername() {
        return tfUsername.getText().trim();
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 4) return false;
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) return false;
        }
        return true;
    }

    public static boolean isSucceeded() {
        return succeeded;
    }

    public boolean authenticate(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
                 PreparedStatement ps = connection.prepareStatement(
                         "SELECT * FROM userinfor WHERE username = ? AND password = ?")) {
                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                return rs.next();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean register(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012")) {

                // Check if user already exists
                PreparedStatement checkStmt = connection.prepareStatement(
                        "SELECT * FROM userinfor WHERE username = ?");
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    return false; // username exists
                }

                // Insert new user
                PreparedStatement insertStmt = connection.prepareStatement(
                        "INSERT INTO userinfor (username, password) VALUES (?, ?)");
                insertStmt.setString(1, username);
                insertStmt.setString(2, password);
                insertStmt.executeUpdate();
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    
}

