package Password;

import javax.swing.*;

public class SQLInjectionauthenticate {
    public static void main(String[] args) {
    	

        SwingUtilities.invokeLater(() -> {   
            SQLInjection loginDialog = new SQLInjection(null);
            loginDialog.setVisible(true);
            if (loginDialog.isSucceeded()) {
                System.out.println("Login successful for: " + loginDialog.getUsername());
            }

         
        });
    }
}
