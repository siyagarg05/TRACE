package Password;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import java.util.*;
import Password.*;
/**
 * A simple example showing how to create a datacenter with one host and run one
 * cloudlet on it.
 */
public class INSECUREAPI {

	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmlist;

	/**
	 * Creates main() to run this example.
	 *
	 * @param args the args
	 */
	@SuppressWarnings("unused")
	static int vmid;
	static int mips;
	static long size;// image size (MB)
	static int ram;// vm memory (MB)
	static long bw;
	static int pesNumber;// number of cpus
	static String vmm;// VMM name
	public static void main(String[] args) {

	    Log.printLine("Starting CloudSimExample1...");
	    Scanner sc = new Scanner(System.in);

	    try {
	        // Start timer for full simulation
	        long simStartTime = System.currentTimeMillis();

	        // Initialize CloudSim
	        int num_user = 1;
	        Calendar calendar = Calendar.getInstance();
	        boolean trace_flag = false;
	        CloudSim.init(num_user, calendar, trace_flag);

	        Datacenter datacenter0 = createDatacenter("Datacenter_0");
	        DatacenterBroker broker = createBroker();
	        int brokerId = broker.getId();

	        vmlist = new ArrayList<Vm>();

	        // VM input
	        System.out.println("Enter vm id");
	        int vmid = sc.nextInt();
	        System.out.print("Enter CPU speed ");
	        int mips = sc.nextInt();
	        System.out.print("Enter image size in MB ");
	        long size = sc.nextLong();
	        System.out.print("Enter memory size ");
	        int ram = sc.nextInt();
	        System.out.print("Enter bandwidth ");
	        long bw = sc.nextLong();
	        System.out.print("Enter no of CPUs ");
	        int pesNumber = sc.nextInt();
	        System.out.print("Enter VM name ");
	        String vmm = sc.next();

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");

	        String query = "INSERT INTO cloud_resource (vmid,mips, size, ram, bw, pesNumber,vmm) VALUES (?, ?, ?, ?, ?, ?, ?)";
	        PreparedStatement ps = connection.prepareStatement(query);
	        ps.setInt(1, vmid);
	        ps.setInt(2, mips);
	        ps.setLong(3, size);
	        ps.setInt(4, ram);
	        ps.setLong(5, bw);
	        ps.setInt(6, pesNumber);
	        ps.setString(7, vmm);

	        int num1 = ps.executeUpdate();
	        System.out.println("No of rows entered: " + num1);   
	        connection.close();

	        // Run the attack and measure its execution time
	        long attackStart = System.nanoTime();
	        attack();
	        long attackEnd = System.nanoTime();
	        System.out.println("Attack launch time: " + (attackEnd - attackStart) / 1000000.0 + " ms");

	        // Create and submit VM
	        Vm vm = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());
	        vmlist.add(vm);
	        broker.submitVmList(vmlist);

	        // Create and submit Cloudlet
	        cloudletList = new ArrayList<Cloudlet>();
	        int id = 0;
	        long length = 400000;
	        long fileSize = 300;
	        long outputSize = 300;
	        UtilizationModel utilizationModel = new UtilizationModelFull();
	        Cloudlet cloudlet = new Cloudlet(id, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
	        cloudlet.setUserId(brokerId);
	        cloudlet.setVmId(vmid);
	        cloudletList.add(cloudlet);
	        broker.submitCloudletList(cloudletList);

	        // Start simulation and measure execution time
	        long simulationStart = System.currentTimeMillis();
	        CloudSim.startSimulation();
	        CloudSim.stopSimulation();
	        long simulationEnd = System.currentTimeMillis();

	        List<Cloudlet> newList = broker.getCloudletReceivedList();
	        printCloudletList(newList);

	        System.out.println("CloudSim simulation time: " + (simulationEnd - simulationStart) + " ms");

	        // End timer for full simulation
	        long simEndTime = System.currentTimeMillis();
	        System.out.println("Total program time: " + (simEndTime - simStartTime) + " ms");

	        Log.printLine("CloudSimExample1 finished!");
	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.printLine("Unwanted errors happen");
	    }
	}

		
	
	static void attack() {
	    try {
	        System.out.println("Launching Insecure API Attack: SQL Injection Simulation...");

	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");

	        String attackerInput = "' OR '1'='1";
	        String query = "SELECT * FROM cloud_resource WHERE vmm = '" + attackerInput + "'";
	        System.out.println("Executing: " + query);

	        Statement stmt = con.createStatement();
	        var rs = stmt.executeQuery(query);

	        System.out.println("Result of SQL Injection:");
	        while (rs.next()) {
	            System.out.println("  vmid: " + rs.getInt("vmid") + ", vmm: " + rs.getString("vmm"));
	        }

	        con.close();
	    } catch (Exception e) {
	        System.out.println("Attack failed or blocked: " + e.getMessage());
	    }
	}


	

	/**
	 * Creates the datacenter.
	 *
	 * @param name the name
	 *
	 * @return the datacenter
	 */
	private static Datacenter createDatacenter(String name) {

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store
		// our machine
		List<Host> hostList = new ArrayList<Host>();

		// 2. A Machine contains one or more PEs or CPUs/Cores.
		// In this example, it will have only one core.
		List<Pe> peList = new ArrayList<Pe>();

		int mips = 1000;

		// 3. Create PEs and add these into a list.
		peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating

		// 4. Create Host with its id and list of PEs and add them to the list
		// of machines
		int hostId = 0;
		int ram = 2048; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 10000;

		hostList.add(
			new Host(
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerSimple(bw),
				storage,
				peList,
				new VmSchedulerTimeShared(peList)
			)
		); // This is our machine

		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
										// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
													// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		// 6. Finally, we need to create a PowerDatacenter object.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 *
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker() {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	/**
	 * Prints the Cloudlet objects.
	 *
	 * @param list list of Cloudlets
	 */
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getExecStartTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
			}
		}
	}

}
