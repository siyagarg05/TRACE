package Password;
import java.util.*;

//import org.cloudbus.cloudsim.examples.cloud;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Base2 {
	public static void main(String args[])
	{  Scanner sc=new Scanner(System.in);
		System.out.println("Choose the attack you want to simulate\n 1.SQL Injection \n 2.Weak Authentication\n 3.Insider threat\n 4.Denial of Service");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			try {System.out.println("Simulating SQL Injection Attack");
		             INJECTIONAUTHENTICATE.main(args);}
			 catch (Exception e) {
		            e.printStackTrace();}
			break;
			
		case 2:System.out.println("Simulating Insecure API attack via Weak Authentication");
	        Attack.main(args);
		    break;
	    case 3:System.out.println("Simulating Insider threat");
	       INSECURE.main(args);
	       break;
	     case 4:System.out.println("Simulating Denial of Service(DoS)Attack");
	            Tcpcs.main(args);
	            Tcpc.main(args);
	         
	      break;
	
		default:System.out.println("Invalid input");
		
		}
		
		
		
	}

}
