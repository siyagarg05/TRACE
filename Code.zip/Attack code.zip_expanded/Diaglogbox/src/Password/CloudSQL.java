package Password;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import java.util.*;
import Password.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 * A simple example showing how to create a datacenter with one host and run one
 * cloudlet on it.
 */
public class CloudSQL {

	/** The cloudlet list. */
	private static List<Cloudlet> cloudletList;

	/** The vmlist. */
	private static List<Vm> vmlist;

	/**
	 * Creates main() to run this example.
	 *
	 * @param args the args
	 */
	@SuppressWarnings("unused")
	static int vmid;
	static int mips;
	static long size;// image size (MB)
	static int ram;// vm memory (MB)
	static long bw;
	static int pesNumber;// number of cpus
	static String vmm;// VMM name
	public static void main(String[] args) {
		//Authenticate.demo(); // This triggers the login dialog from Main class.
		INJECTIONAUTHENTICATE.main(args);
		
         
         
        // Assuming that if the login is successful, proceed with CloudSim simulation
        if (INJECTIONATTACK.isSucceeded()) {
            Log.printLine("Login successful! Proceeding with CloudSim simulation...");
        
		Log.printLine("Starting CloudSimExample1...");
        Scanner sc=new Scanner(System.in);
		try {
			// First step: Initialize the CloudSim package. It should be called
			// before creating any entities.
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; // mean trace events

			// Initialize the CloudSim library
	  		CloudSim.init(num_user, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			Datacenter datacenter0 = createDatacenter("Datacenter_0");

			// Third step: Create Broker
			DatacenterBroker broker = createBroker();
			int brokerId = broker.getId();

			// Fourth step: Create one virtual machine
			vmlist = new ArrayList<Vm>();

			// VM description
			System.out.println("Enter vm id");

			
			int vmid = sc.nextInt();
			System.out.print("Enter CPU speed ");
			int mips = sc.nextInt();
			System.out.print("Enter image size in MB ");
			long size = sc.nextLong(); // image size (M
			System.out.print("Enter memory size ");
			int ram = sc.nextInt(); // vm memory (MB)
			System.out.print("Enter bandwidth ");
			long bw = sc.nextLong();
			System.out.print("Enter no of CPUs ");
			int pesNumber = sc.nextInt(); // number of cpus
			System.out.print("Enter VM name ");
			String vmm = sc.next(); // VMM name

			 /*     Class.forName("com.mysql.cj.jdbc.Driver");
			    Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud","root","Informatics@2010");
			    Statement statement = connection.createStatement();
			    //int num1=statement.executeUpdate("insert into cloud_resource values('mips','size','ram','bw','pesNumber')");
			    String query = "INSERT INTO cloud_resource (vmid,mips, size, ram, bw, pesNumber,vmm) VALUES (?, ?, ?, ?, ?, ?, ?)";
			    PreparedStatement ps = connection.prepareStatement(query);
			    ps.setInt(1, vmid);
			    ps.setInt(2, mips);
			    ps.setLong(3, size);
			    ps.setInt(4, ram);
			    ps.setLong(5, bw);
			    ps.setInt(6, pesNumber);
			    ps.setString(7, vmm);

			    int num1 = ps.executeUpdate();
			    System.out.println("No of rows entered: " + num1);   
			   
			        connection.close();
			 */
			 vmid = 1;
			/* mips = 1000;
			 size = 10000; // image size (MB)
			ram = 512; // vm memory (MB)
			bw = 1000;
			pesNumber = 1; // number of cpus */
			vmm = "Xen"; 
             attack();
			// create VM
			Vm vm = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());

			// add the VM to the vmList
			vmlist.add(vm);

			// submit vm list to the broker
			broker.submitVmList(vmlist);

			// Fifth step: Create one Cloudlet
			cloudletList = new ArrayList<Cloudlet>();

			// Cloudlet properties
			int id = 0;
			long length = 400000;
			long fileSize = 300;
			long outputSize = 300;
			UtilizationModel utilizationModel = new UtilizationModelFull();

			Cloudlet cloudlet = new Cloudlet(id, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(vmid);

			// add the cloudlet to the list
			cloudletList.add(cloudlet);

			// submit cloudlet list to the broker
			broker.submitCloudletList(cloudletList);

			// Sixth step: Starts the simulation
			CloudSim.startSimulation();

			CloudSim.stopSimulation();

			//Final step: Print results when simulation is over
			List<Cloudlet> newList = broker.getCloudletReceivedList();
			printCloudletList(newList);

			Log.printLine("CloudSimExample1 finished!");
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}}
		/* else
			System.out.print("Invalid credentials!Enter again\n");*/}
	
	static void attack() {
	    try {
	        // Connect to DB
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection connection = DriverManager.getConnection(
	            "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012"
	        );

	        int targetVM = 3; // the VM we want to attack (you can change this)

	        // Step 1: Show BEFORE values
	        System.out.println("=== BEFORE ATTACK ===");
	        PreparedStatement selectBefore = connection.prepareStatement(
	            "SELECT * FROM cloud_resource WHERE vmid=?"
	        );
	        selectBefore.setInt(1, targetVM);
	        ResultSet beforeRS = selectBefore.executeQuery();
	        if (beforeRS.next()) {
	            System.out.println("VMID: " + beforeRS.getInt("vmid") +
	                               ", MIPS: " + beforeRS.getInt("mips") +
	                               ", RAM: " + beforeRS.getInt("ram") +
	                               ", BW: " + beforeRS.getInt("bw") +
	                               ", CPUs: " + beforeRS.getInt("pesNumber") +
	                               ", VMM: " + beforeRS.getString("vmm"));
	        } else {
	            System.out.println("No record found for VMID " + targetVM);
	        }

	        // Step 2: Update with malicious values
	        int newVMID = 3333; // malicious ID
	        mips = 50000;
	        size = 9000;
	        ram = 7183;
	        bw = 20000;
	        pesNumber = 8;
	        vmm = "MaliciousVMM";

	        String updateSQL = "UPDATE cloud_resource SET vmid=?, mips=?, size=?, ram=?, bw=?, pesNumber=?, vmm=? WHERE vmid=?";
	        PreparedStatement update = connection.prepareStatement(updateSQL);
	        update.setInt(1, newVMID);
	        update.setInt(2, mips);
	        update.setLong(3, size);
	        update.setInt(4, ram);
	        update.setLong(5, bw);
	        update.setInt(6, pesNumber);
	        update.setString(7, vmm);
	        update.setInt(8, targetVM);
	        int rows = update.executeUpdate();

	        if (rows > 0) {
	            System.out.println("!!! ALERT: Cloud resources maliciously modified !!!");
	        } else {
	            System.out.println("No rows updated — target VM not found.");
	        }

	        // Step 3: Show AFTER values
	        System.out.println("=== AFTER ATTACK ===");
	        PreparedStatement selectAfter = connection.prepareStatement(
	            "SELECT * FROM cloud_resource WHERE vmid=?"
	        );
	        selectAfter.setInt(1, newVMID);
	        ResultSet afterRS = selectAfter.executeQuery();
	        if (afterRS.next()) {
	            System.out.println("VMID: " + afterRS.getInt("vmid") +
	                               ", MIPS: " + afterRS.getInt("mips") +
	                               ", RAM: " + afterRS.getInt("ram") +
	                               ", BW: " + afterRS.getInt("bw") +
	                               ", CPUs: " + afterRS.getInt("pesNumber") +
	                               ", VMM: " + afterRS.getString("vmm"));
	        } else {
	            System.out.println("No record found for VMID " + newVMID);
	        }

	        connection.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.printLine("Error during malicious resource modification.");
	    }
	}

	/**
	 * Creates the datacenter.
	 *
	 * @param name the name
	 *
	 * @return the datacenter
	 */
	private static Datacenter createDatacenter(String name) {

		// Here are the steps needed to create a PowerDatacenter:
		// 1. We need to create a list to store
		// our machine
		List<Host> hostList = new ArrayList<Host>();

		// 2. A Machine contains one or more PEs or CPUs/Cores.
		// In this example, it will have only one core.
		List<Pe> peList = new ArrayList<Pe>();

		int mips = 1000;

		// 3. Create PEs and add these into a list.
		peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating

		// 4. Create Host with its id and list of PEs and add them to the list
		// of machines
		int hostId = 0;
		int ram = 2048; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 10000;

		hostList.add(
			new Host(
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerSimple(bw),
				storage,
				peList,
				new VmSchedulerTimeShared(peList)
			)
		); // This is our machine

		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
										// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
													// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		// 6. Finally, we need to create a PowerDatacenter object.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 *
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker() {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	/**
	 * Prints the Cloudlet objects.
	 *
	 * @param list list of Cloudlets
	 */
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getExecStartTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
			}
		}
	}

}