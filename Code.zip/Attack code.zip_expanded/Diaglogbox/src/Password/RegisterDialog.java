 package Password;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class RegisterDialog extends JDialog {

    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JLabel lbUsername;
    private JLabel lbPassword;
    private JButton btnRegister;
    private JButton btnCancel;

    public RegisterDialog(Frame parent) {
        super(parent, "Register", true);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;

        lbUsername = new JLabel("Username: ");
        cs.gridx = 0; cs.gridy = 0; cs.gridwidth = 1;
        panel.add(lbUsername, cs);

        tfUsername = new JTextField(20);
        cs.gridx = 1; cs.gridy = 0; cs.gridwidth = 2;
        panel.add(tfUsername, cs);

        lbPassword = new JLabel("Password (4+ letters/digits): ");
        cs.gridx = 0; cs.gridy = 1; cs.gridwidth = 1;
        panel.add(lbPassword, cs);

        pfPassword = new JPasswordField(20);
        cs.gridx = 1; cs.gridy = 1; cs.gridwidth = 2;
        panel.add(pfPassword, cs);

        btnRegister = new JButton("Register");
        btnRegister.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String pass = new String(pfPassword.getPassword());

            if (!isValidPassword(pass)) {
                JOptionPane.showMessageDialog(RegisterDialog.this,
                        "Password must be at least 4 characters long and contain only letters and digits.",
                        "Invalid Password",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(RegisterDialog.this,
                        "Username cannot be empty.",
                        "Invalid Username",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (isUserExist(username)) {
                JOptionPane.showMessageDialog(RegisterDialog.this,
                        "Username already exists. Please choose another.",
                        "Duplicate Username",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (registerUser(username, pass)) {
                JOptionPane.showMessageDialog(RegisterDialog.this,
                        "Registration successful! You can now login.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(RegisterDialog.this,
                        "Registration failed. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());

        JPanel bp = new JPanel();
        bp.add(btnRegister);
        bp.add(btnCancel);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 4) return false;
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) return false;
        }
        return true;
    }

    private boolean isUserExist(String username) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
                 PreparedStatement ps = connection.prepareStatement(
                         "SELECT username FROM userinfor WHERE username = ?")) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean registerUser(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
                 PreparedStatement ps = connection.prepareStatement(
                         "INSERT INTO userinfor (username, password) VALUES (?, ?)")) {
                ps.setString(1, username);
                ps.setString(2, password);
                int rowsInserted = ps.executeUpdate();
                return rowsInserted > 0;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}