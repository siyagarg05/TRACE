package Password;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.*;

import org.cloudbus.cloudsim.*;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.*;

public class INSECURE {

    private static List<Cloudlet> cloudletList;
    private static List<Vm> vmlist;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Log.printLine("Insider threat attack launched:");

        // Step 1: Simulate stolen credentials
        System.out.println("=== Insecure Login ===");
        System.out.print("Enter username: ");
        String username = sc.nextLine();
        System.out.print("Enter password: ");
        String password = sc.nextLine();
        

        if (!weakLogin(username, password)) {
            System.out.println("Login failed. Exiting.");
            return;
        }

        System.out.println("Login successful as: " + username);

    
        long attackStart = System.nanoTime();
        leakUserInfo();  
        long attackEnd = System.nanoTime();
        System.out.printf("Attack time: %.3f ms\n", (attackEnd - attackStart) / 1000000.0);

       
        try {
            long simStartTime = System.currentTimeMillis();

            int num_user = 1;
            Calendar calendar = Calendar.getInstance();
            boolean trace_flag = false;
            CloudSim.init(num_user, calendar, trace_flag);

            Datacenter datacenter0 = createDatacenter("Datacenter_0");
            DatacenterBroker broker = createBroker();
            int brokerId = broker.getId();
            vmlist = new ArrayList<>();

            System.out.println("\n...Enter VM Details to Simulate...");
            System.out.println("Enter vm id");
	        int vmid = sc.nextInt();
	        System.out.print("Enter CPU speed ");
	        int mips = sc.nextInt();
	        System.out.print("Enter image size in MB ");
	        long size = sc.nextLong();
	        System.out.print("Enter memory size ");
	        int ram = sc.nextInt();
	        System.out.print("Enter bandwidth ");
	        long bw = sc.nextLong();
	        System.out.print("Enter no of CPUs ");
	        int pesNumber = sc.nextInt();
	        System.out.print("Enter VM name ");
	        String vmm = sc.next();

            // Store compromised resource request
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
            String query = "INSERT INTO cloud_resource (vmid,mips,size,ram,bw,pesNumber,vmm) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, vmid); ps.setInt(2, mips); ps.setLong(3, size);
            ps.setInt(4, ram); ps.setLong(5, bw); ps.setInt(6, pesNumber); ps.setString(7, vmm);
            int rows = ps.executeUpdate();
            System.out.println("DB rows inserted: " + rows);
            conn.close();

            // Launch simulation
            Vm vm = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());
            vmlist.add(vm);
            broker.submitVmList(vmlist);

            cloudletList = new ArrayList<>();
            long length = 400000, fileSize = 300, outputSize = 300;
            UtilizationModel utilizationModel = new UtilizationModelFull();
            Cloudlet cloudlet = new Cloudlet(0, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
            cloudlet.setUserId(brokerId);
            cloudlet.setVmId(vmid);
            cloudletList.add(cloudlet);
            broker.submitCloudletList(cloudletList);

            long simStart = System.currentTimeMillis();
            CloudSim.startSimulation();
            CloudSim.stopSimulation();
            long simEnd = System.currentTimeMillis();

            List<Cloudlet> results = broker.getCloudletReceivedList();
            printCloudletList(results);

            System.out.println("CloudSim simulation time: " + (simEnd - simStart) + " ms");
            System.out.println("Total program time: " + (System.currentTimeMillis() - simStartTime) + " ms");

        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen.");
        }
    }

    // --- Weak Auth ---
    static boolean weakLogin(String username, String password) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
            String query = "SELECT * FROM userinfor WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password); // <- Plaintext match
            ResultSet rs = ps.executeQuery();
            return rs.next(); // True if match found
        } catch (Exception e) {
             e.printStackTrace();
            return false;
        }
    }

    // --- Simulates user data compromise ---
    static void leakUserInfo() {
    	
        System.out.println("\n Displaying all user accounts:");
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
            String query = "SELECT * FROM userinfor";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println("User: " + rs.getString("username") + ", Password: " + rs.getString("password"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- Simulation Setup ---
    private static Datacenter createDatacenter(String name) {
        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();
        peList.add(new Pe(0, new PeProvisionerSimple(1000)));

        int hostId = 0;
        int ram = 2048;
        long storage = 1000000;
        int bw = 10000;

        hostList.add(new Host(hostId, new RamProvisionerSimple(ram),
                new BwProvisionerSimple(bw), storage, peList, new VmSchedulerTimeShared(peList)));

        String arch = "x86", os = "Linux", vmm = "Xen";
        double time_zone = 10.0, cost = 3.0, costPerMem = 0.05, costPerStorage = 0.001, costPerBw = 0.0;

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);

        try {
            return new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), new LinkedList<>(), 0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static DatacenterBroker createBroker() {
        try {
            return new DatacenterBroker("Broker");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void printCloudletList(List<Cloudlet> list) {
        String indent = "    ";
        Log.printLine("\n========== OUTPUT ==========");
        Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
                + "Data center ID" + indent + "VM ID" + indent + "Time" + indent
                + "Start Time" + indent + "Finish Time");

        DecimalFormat dft = new DecimalFormat("###.##");
        for (Cloudlet cloudlet : list) {
            if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
                Log.printLine(cloudlet.getCloudletId() + indent + "SUCCESS" + indent
                        + cloudlet.getResourceId() + indent + indent
                        + cloudlet.getVmId() + indent + indent
                        + dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getExecStartTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
        	}
		}
	}

}
