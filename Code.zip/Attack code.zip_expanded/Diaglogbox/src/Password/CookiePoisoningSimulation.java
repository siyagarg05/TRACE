package Password;


import java.util.HashMap;
import java.util.Map;

public class CookiePoisoningSimulation {

    // Simulating a simple session store
    private static Map<String, String> sessionStore = new HashMap<>();

    // Create a cookie for a user
    public static String createCookie(String username, String role) {
        String cookie = username + ":" + role;
        
        sessionStore.put(username, cookie);  // store original
        return cookie;
    }

    // Validate the cookie (basic version)
    public static boolean validateCookie(String cookie) {
        for (String stored : sessionStore.values()) {
            if (stored.equals(cookie)) {
                return true;
            }
        }
        return false;
    }

    // Simulate an attacker modifying the cookie
    public static String poisonCookie(String newRole) {
       
        String poisoned = "admin" + ":" + newRole;
        return poisoned;
    }

    /*public static void main(String[] args) {
        System.out.println(CPattack());
    }*/
    public static String CPattack() {
        System.out.println("Cloud User Login ");
        String originalCookie = createCookie("user123", "user");
        System.out.println("Original Cookie: \n" + "Username : Role\n"+originalCookie);
        //System.out.println("Valid? " + validateCookie(originalCookie));  // should be true

        System.out.println("\n Attacker Modifies Cookie");
        String poisonedCookie = poisonCookie("administrator");
        
        System.out.println("Poisoned Cookie: \n" + "Username : Role\n"+poisonedCookie);
        //System.out.println("Valid? " + validateCookie(poisonedCookie));  // false unless validation is weak
        String modifieduser=poisonedCookie.substring(0,5);
        //System.out.println(modifieduser);
        return modifieduser;
        
    }
}



