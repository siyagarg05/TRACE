  package Password;

import javax.swing.*;

public class INJECTIONAUTHENTICATE {
  
    public static void main(String[] args) {
        try {
            SwingUtilities.invokeLater(() -> {
            	
                INJECTIONATTACK loginDialog = new INJECTIONATTACK(null);
                //System.out.println("About to show login dialog");
                loginDialog.setVisible(true);
                //System.out.println("Login dialog closed");
                long attackStart = System.nanoTime();
                
           	 
                if (loginDialog.isSucceeded()) {
                    System.out.println("Login successful for: " + loginDialog.getUsername());
                    CloudSQL.attack();
               long attackEnd = System.nanoTime();
               System.out.printf("Attack time: %.3f ms\n", (attackEnd - attackStart) / 1000000.0);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
