package Password;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class INJECTIONATTACK extends JDialog {

    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JLabel lbUsername;
    private JLabel lbPassword;
    private JButton btnLogin;
    private JButton btnRegister;
    private JButton btnCancel;
    private static boolean succeeded;

    public INJECTIONATTACK(Frame parent) {
    	  
        super(parent, "Login / Register", true);
       
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;

        lbUsername = new JLabel("Username: ");
        cs.gridx = 0;
        cs.gridy = 0;
        cs.gridwidth = 1;
        panel.add(lbUsername, cs);

        tfUsername = new JTextField(20);
        cs.gridx = 1;
        cs.gridy = 0;
        cs.gridwidth = 2;
        panel.add(tfUsername, cs);

        lbPassword = new JLabel("Password: ");
        cs.gridx = 0;
        cs.gridy = 1;
        cs.gridwidth = 1;
        panel.add(lbPassword, cs);

        pfPassword = new JPasswordField(20);
        cs.gridx = 1;
        cs.gridy = 1;
        cs.gridwidth = 2;
        panel.add(pfPassword, cs);

        panel.setBorder(BorderFactory.createTitledBorder("Login Panel"));

        btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (authenticate(username, password)) {
                JOptionPane.showMessageDialog(INJECTIONATTACK.this,
                        "Hi " + username + "! You have successfully logged in.",
                        "Login", JOptionPane.INFORMATION_MESSAGE);
                succeeded = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(INJECTIONATTACK.this,
                        "Invalid username or password",
                        "Login Failed", JOptionPane.ERROR_MESSAGE);
                tfUsername.setText("");
                pfPassword.setText("");
                succeeded = false;
            }
        });

        btnRegister = new JButton("Register");
        btnRegister.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (!isValidPassword(password)) {
                JOptionPane.showMessageDialog(INJECTIONATTACK.this,
                        "Password must be at least 4 characters with only letters and digits.",
                        "Invalid Password", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (register(username, password)) {
                JOptionPane.showMessageDialog(INJECTIONATTACK.this,
                        "Registration successful! You can now login.",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(INJECTIONATTACK.this,
                        "Username already exists or registration failed.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());

        JPanel bp = new JPanel();
        bp.add(btnLogin);
        bp.add(btnRegister);
        bp.add(btnCancel);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        //setAlwaysOnTop(true);
        
        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    public String getUsername() {
        return tfUsername.getText().trim();
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 4) return false;
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) return false;
        }
        return true;
    }

    public static boolean isSucceeded() {
        return succeeded;
    }

    public boolean authenticate(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012");
                 Statement st = connection.createStatement()) {

                // ⚠️ Vulnerable query (intentionally for SQL Injection simulation)
                String query = "SELECT * FROM userinfor WHERE username = '" + username + "' AND password = '" + password + "'";
                System.out.println("Executing query: " + query);

                ResultSet rs = st.executeQuery(query);

                // Create table model
                DefaultTableModel tableModel = new DefaultTableModel();
                tableModel.addColumn("username");
                tableModel.addColumn("Password");

                boolean found = false;
                while (rs.next()) {
                    found = true;
                    tableModel.addRow(new Object[]{
                            rs.getString("username"),
                            rs.getString("password")
                    });
                }
                succeeded=found;
                if (found) {
                    JTable table = new JTable(tableModel);
                    JScrollPane scrollPane = new JScrollPane(table);
                    scrollPane.setPreferredSize(new Dimension(400, 200));

                    JOptionPane.showMessageDialog(null, scrollPane, "Users Record (Leaked via SQLi)", JOptionPane.INFORMATION_MESSAGE);
                    return true;
                } else {
                    return false;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean register(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cloud", "root", "Informatics@2012")) {

                // Check if user already exists
                PreparedStatement checkStmt = connection.prepareStatement(
                        "SELECT * FROM userinfor WHERE username = ?");
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    return false; // username exists
                }

                // Insert new user
                PreparedStatement insertStmt = connection.prepareStatement(
                        "INSERT INTO userinfor (username, password) VALUES (?, ?)");
                insertStmt.setString(1, username);
                insertStmt.setString(2, password);
                insertStmt.executeUpdate();
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
