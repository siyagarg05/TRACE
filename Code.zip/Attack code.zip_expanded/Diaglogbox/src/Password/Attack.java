package Password;

public class Attack{
 public static void main(String args[]) {
     
	System.out.println("....Stealing user credentials using Brute force....");
	 Brute.main(args);
	 System.out.println(".....Launching Insecure API via Weak Authenication......");
     long attackStart = System.nanoTime();
     try {
    	 INJECTIONAUTHENTICATE w=new INJECTIONAUTHENTICATE();
    	 w.main(args);
    	} catch (Exception e) {
    	    System.err.println("Error");
    	    e.printStackTrace();
    	}
	 long attackEnd = System.nanoTime();
     System.out.printf("Attack time: %.3f ms\n", (attackEnd - attackStart) / 1000000.0);
 }
}
