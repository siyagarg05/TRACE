package Password;
import java.net.*;
import java.io.*;
class Tcpcs
{
 public static void main(String args[])
 {
 ServerSocket ss;
 Socket s;
 String str="Hello Client";
 try
 {
  ss=new ServerSocket(8888);
  System.out.println("Yes..ready to receive the requests");
  s=ss.accept();
  OutputStream os=s.getOutputStream();
  DataOutputStream dos=new DataOutputStream(os);
  dos.writeUTF(str);
  dos.close();
  os.close();
 } catch(Exception e) {
	    e.printStackTrace();  // shows the real error
 }
}}
