package com.siyagarg.wallet;

import org.bitcoinj.core.Address;
import org.bitcoinj.core.NetworkParameters;
import org.bitcoinj.params.TestNet3Params;
import org.bitcoinj.script.Script;
import org.bitcoinj.wallet.Wallet;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;

public class Cryptomining {

    private static double totalReceived = 0.0;
    private static double totalSent = 0.0;
    private static double totalHijacked = 0.0;
    private static final int SIMULATION_CYCLES = 15;
    private static final double MAX_SEND_RATE = 0.03;

    private static boolean attackerActive = false;
    private static double hijackRate = 0.0;

    private static final Random random = new Random();

    public static void main(String[] args) {
    	long startTime = System.currentTimeMillis(); 
        try {
            DecimalFormat df = new DecimalFormat("0.0000");

            NetworkParameters params = TestNet3Params.get();
            Wallet wallet = Wallet.createDeterministic(
                    params, Script.ScriptType.P2PKH);

            Address address = wallet.freshReceiveAddress();
            wallet.saveToFile(new File("mywallet.wallet"));

            System.out.println("Wallet address: " + address);
            System.out.println("\n CRYPTOMINING ATTACK SIMULATION \n");

            for (int cycle = 1; cycle <= SIMULATION_CYCLES; cycle++) {

                if (cycle == 5) {
                    attackerActive = true;
                    System.out.println("Attacker infiltration detected");
                }

                if (attackerActive && hijackRate < 0.45) {
                    hijackRate += 0.05; // attacker escalates
                }

                double miningRate =
                        0.02 + (0.06 - 0.02) * random.nextDouble();

                totalReceived += miningRate;

                double hijacked = attackerActive
                        ? miningRate * hijackRate
                        : 0.0;

                totalHijacked += hijacked;

                double usable = miningRate - hijacked;

           
                double sent =
                        Math.min(usable,
                                random.nextDouble() * MAX_SEND_RATE);

                totalSent += sent;

                
                System.out.println("Cycle " + cycle);
                System.out.println("Mined:        " + df.format(miningRate));
                System.out.println("Hijacked:     " + df.format(hijacked));
                System.out.println("Sent:         " + df.format(sent));
                System.out.println("Retained:    " + df.format(usable - sent));
                System.out.println("Hijack rate: " +
                        df.format(hijackRate * 100) + "%\n");

                Thread.sleep(700);
            }

            System.out.println("=== FINAL ANALYSIS ===");
            System.out.println("Total mined:     " + df.format(totalReceived));
            System.out.println("Total sent:      " + df.format(totalSent));
            System.out.println("Total hijacked:  " + df.format(totalHijacked));

            double lossRatio =
                    (totalHijacked / totalReceived) * 100;

            System.out.println("Observed loss:   " +
                    df.format(lossRatio) + "%");
            long endTime = System.currentTimeMillis();
            long totalTime = endTime - startTime;

            System.out.println("Total Attack Time: " + totalTime + " ms");
            
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
