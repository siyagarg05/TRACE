package com.siyagarg.wallet;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.*;

import java.text.DecimalFormat;
import java.util.*;

public class CryptoZeroDay {

    private static final int TOTAL_CYCLES = 10;
    private static final long BASE_WORKLOAD = 400000;
    private static final int VM_MIPS = 1000;

    private static double totalMined = 0;
    private static double totalHijacked = 0;
    private static double totalAttackTime = 0;

    private static final double W1 = 0.30;
    private static final double W2 = 0.25;
    private static final double W3 = 0.25;
    private static final double W4 = 0.20;

    private static final double TAU = 0.40;
    private static final double K = 10.0;

    public static void main(String[] args) {

        System.out.println("Zero-Day Simulation");

        long simulationStart = System.currentTimeMillis();

        SimulationResult baseline = runSimulation(0);
        double baselineTime = baseline.legitTime;

        for (int cycle = 1; cycle <= TOTAL_CYCLES; cycle++) {

            double hijackRate = getHijackRate(cycle);
            SimulationResult result = runSimulation(hijackRate);

            double execTime = result.legitTime;
            double degradation = ((execTime - baselineTime) / baselineTime) * 100;

            double mined = simulateMining(cycle);
            double hijacked = mined * hijackRate;

            totalMined += mined;
            totalHijacked += hijacked;

            double resourceRatio = (execTime > 0)
                    ? result.attackTime / execTime
                    : 0;

            double lossRatio = (mined > 0)
                    ? hijacked / mined
                    : 0;

            double probability;

            
            if (cycle == 1) {
                probability = 0.99;
            } else {
                probability = computeZeroDayProbability(
                        hijackRate,
                        degradation,
                        resourceRatio,
                        lossRatio
                );
            }

            System.out.println("\n--- Cycle " + cycle + " ---");
            System.out.println("Hijack Rate: " + format(hijackRate * 100) + "%");
            System.out.println("Execution Time: " + format(execTime));
            System.out.println("Performance Degradation: " + format(degradation) + "%");
            System.out.println("Mined: " + format(mined));
            System.out.println("Hijacked: " + format(hijacked));
            System.out.println("Zero-Day Probability: " + format(probability * 100) + "%");

            // 🎭 Zero-day illusion
            if (Math.random() < probability) {

                System.out.println("\n[INFO] Monitoring VM resource usage...");
                System.out.println("[DEBUG] CPU usage spike detected (unexpected)");
                System.out.println("[WARN] Unrecognized process initiated inside VM");

                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                System.out.println("[ALERT] Privilege escalation attempt detected");
                System.out.println("\n Zero-day attack launched.");
                System.out.println(" System malfunction.");

                break;
            }
        }

        long simulationEnd = System.currentTimeMillis();
        long totalSimulationTimeMs = simulationEnd - simulationStart;

        System.out.println("\nTotal time to attack: " + totalSimulationTimeMs + " ms");
    }

    private static double computeZeroDayProbability(
            double hijackRate,
            double degradation,
            double resourceRatio,
            double lossRatio) {

        double Hn = hijackRate;
        double Dn = degradation / 100.0;
        double Rn = resourceRatio;
        double Ln = lossRatio;

        double risk = W1 * Hn + W2 * Dn + W3 * Rn + W4 * Ln;

        return 1.0 / (1.0 + Math.exp(-K * (risk - TAU)));
    }

    private static SimulationResult runSimulation(double attackIntensity) {

        try {
            CloudSim.init(1, Calendar.getInstance(), false);

            Datacenter datacenter = createDatacenter("DC");
            DatacenterBroker broker = new DatacenterBroker("Broker");
            int brokerId = broker.getId();

            Vm vm = new Vm(
                    0, brokerId, VM_MIPS, 1,
                    512, 1000, 10000,
                    "Xen",
                    new CloudletSchedulerTimeShared()
            );

            broker.submitVmList(Collections.singletonList(vm));

            List<Cloudlet> cloudletList = new ArrayList<>();

            Cloudlet legit = createCloudlet(0, BASE_WORKLOAD, brokerId);
            cloudletList.add(legit);

            if (attackIntensity > 0) {
                long attackLoad = (long) (BASE_WORKLOAD * attackIntensity * 1.2); // enhanced attack realism
                Cloudlet attacker = createCloudlet(1, attackLoad, brokerId);
                cloudletList.add(attacker);
            }

            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            List<Cloudlet> results = broker.getCloudletReceivedList();

            double legitFinishTime = 0;
            double attackTime = 0;

            for (Cloudlet c : results) {
                if (c.getCloudletId() == 0) {
                    legitFinishTime = c.getFinishTime();
                }
                if (c.getCloudletId() == 1) {
                    attackTime = c.getFinishTime() - c.getExecStartTime();
                    totalAttackTime += attackTime;
                }
            }

            return new SimulationResult(legitFinishTime, attackTime);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimulationResult(0, 0);
    }

    private static Cloudlet createCloudlet(int id, long length, int brokerId) {
        Cloudlet cloudlet = new Cloudlet(
                id, length, 1,
                300, 300,
                new UtilizationModelFull(),
                new UtilizationModelFull(),
                new UtilizationModelFull()
        );

        cloudlet.setUserId(brokerId);
        cloudlet.setVmId(0);

        return cloudlet;
    }

    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();

        peList.add(new Pe(0, new PeProvisionerSimple(VM_MIPS)));

        hostList.add(new Host(
                0,
                new RamProvisionerSimple(2048),
                new BwProvisionerSimple(10000),
                1000000,
                peList,
                new VmSchedulerTimeShared(peList)
        ));

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        "x86", "Linux", "Xen",
                        hostList,
                        10.0, 3.0,
                        0.05, 0.001, 0.0
                );

        try {
            return new Datacenter(
                    name,
                    characteristics,
                    new VmAllocationPolicySimple(hostList),
                    new LinkedList<>(),
                    0
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static double simulateMining(int cycle) {
        if (cycle == 1) return 0.20;
        return 0.02 + (0.06 - 0.02) * Math.random();
    }

    private static double getHijackRate(int cycle) {
        if (cycle == 1) {
            return 0.12; // attack starts immediately
        }
        return 0;
    }

    private static String format(double value) {
        return new DecimalFormat("0.000").format(value);
    }

    private static class SimulationResult {
        double legitTime;
        double attackTime;

        SimulationResult(double legitTime, double attackTime) {
            this.legitTime = legitTime;
            this.attackTime = attackTime;
        }
    }
}