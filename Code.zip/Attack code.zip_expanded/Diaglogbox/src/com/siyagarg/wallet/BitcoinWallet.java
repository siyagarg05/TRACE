package com.siyagarg.wallet;

import org.bitcoinj.core.Address;
import org.bitcoinj.core.NetworkParameters;
import org.bitcoinj.params.TestNet3Params;
import org.bitcoinj.script.Script;
import org.bitcoinj.wallet.Wallet;

import java.io.File;
import java.io.IOException;

public class BitcoinWallet {
    public static void main(String[] args) {
        try {
            
            NetworkParameters params = TestNet3Params.get();

            // Create a deterministic wallet
            Wallet wallet = Wallet.createDeterministic(params, Script.ScriptType.P2PKH);
            System.out.println("New Wallet Created: " + wallet);

            // Generate a fresh receive address
            Address address = wallet.freshReceiveAddress();
            System.out.println("New Bitcoin Address: " + address);

            // Save wallet to disk
            File walletFile = new File("mywallet.wallet");
            wallet.saveToFile(walletFile);
            System.out.println("Wallet saved to: " + walletFile.getAbsolutePath());
            System.out.println("Wallet balance: " + wallet.getBalance().toFriendlyString());

        } catch (IOException e) {
            System.err.println("Failed to save wallet: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
