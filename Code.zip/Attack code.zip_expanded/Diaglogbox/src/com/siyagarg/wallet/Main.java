package com.siyagarg.wallet;

import org.bitcoinj.params.TestNet3Params;

public class Main {
    public static void main(String[] args) {
        System.out.println("BitcoinJ loaded: " + TestNet3Params.get().getId());
    }
}