package com.siyagarg.wallet;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.*;

import java.text.DecimalFormat;
import java.util.*;

public class Backdoor {

    private static final long BASE_WORKLOAD = 400000;
    private static final int VM_MIPS = 1000;

    public static void main(String[] args) {

        System.out.println("Backdoor Attack Impact Simulation");

        // Baseline run (no backdoor)
        SimulationResult baseline = runSimulation(0);
        double baselineTime = baseline.legitTime;

        // Backdoor attack run (30% hidden workload)
        SimulationResult attack = runSimulation(0.30);

        double attackedTime = attack.legitTime;

        double delay = attackedTime - baselineTime;

        double degradation =
                ((attackedTime - baselineTime) / baselineTime) * 100;

        double cpuDrain =
                (attackedTime > 0)
                        ? (attack.attackTime / attackedTime) * 100
                        : 0;

        System.out.println("\n.....BASE TIME....");
        System.out.println("Execution Time: "
                + format(baselineTime));

        System.out.println("\n===== BACKDOOR ACTIVE =====");
        System.out.println("Execution Time: "
                + format(attackedTime));
        System.out.println("Delay Introduced: "
                + format(delay));
        System.out.println("Performance Degradation: "
                + format(degradation) + "%");
        System.out.println("Hidden CPU Drain: "
                + format(cpuDrain) + "%");

        System.out.println("\n===== BACKDOOR IMPACT SUMMARY =====");
        System.out.println("Total Hidden CPU Time: "
                + format(attack.attackTime));
    }

    private static SimulationResult runSimulation(double backdoorIntensity) {

        try {
            CloudSim.init(1, Calendar.getInstance(), false);

            Datacenter datacenter = createDatacenter("DC");
            DatacenterBroker broker = new DatacenterBroker("Broker");
            int brokerId = broker.getId();

            Vm vm = new Vm(
                    0, brokerId, VM_MIPS, 1,
                    512, 1000, 10000,
                    "Xen",
                    new CloudletSchedulerTimeShared()
            );

            broker.submitVmList(Collections.singletonList(vm));

            List<Cloudlet> cloudletList = new ArrayList<>();

            // Legitimate workload
            Cloudlet legit =
                    createCloudlet(0, BASE_WORKLOAD, brokerId);
            cloudletList.add(legit);

            // Backdoor workload (hidden)
            if (backdoorIntensity > 0) {
                long backdoorLoad =
                        (long)(BASE_WORKLOAD * backdoorIntensity);

                Cloudlet backdoor =
                        createCloudlet(1, backdoorLoad, brokerId);

                cloudletList.add(backdoor);
            }

            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            List<Cloudlet> results =
                    broker.getCloudletReceivedList();

            double legitFinish = 0;
            double attackTime = 0;

            for (Cloudlet c : results) {

                if (c.getCloudletId() == 0) {
                    legitFinish = c.getFinishTime();
                }

                if (c.getCloudletId() == 1) {
                    attackTime =
                            c.getFinishTime() -
                            c.getExecStartTime();
                }
            }

            return new SimulationResult(legitFinish, attackTime);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimulationResult(0, 0);
    }

    private static Cloudlet createCloudlet(
            int id, long length, int brokerId) {

        Cloudlet cloudlet = new Cloudlet(
                id, length, 1,
                300, 300,
                new UtilizationModelFull(),
                new UtilizationModelFull(),
                new UtilizationModelFull()
        );

        cloudlet.setUserId(brokerId);
        cloudlet.setVmId(0);

        return cloudlet;
    }

    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();

        peList.add(
                new Pe(0,
                        new PeProvisionerSimple(VM_MIPS)));

        hostList.add(new Host(
                0,
                new RamProvisionerSimple(2048),
                new BwProvisionerSimple(10000),
                1000000,
                peList,
                new VmSchedulerTimeShared(peList)
        ));

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        "x86", "Linux", "Xen",
                        hostList,
                        10.0, 3.0,
                        0.05, 0.001, 0.0
                );

        try {
            return new Datacenter(
                    name,
                    characteristics,
                    new VmAllocationPolicySimple(hostList),
                    new LinkedList<>(),
                    0
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String format(double value) {
        return new DecimalFormat("0.000")
                .format(value);
    }

    private static class SimulationResult {
        double legitTime;
        double attackTime;

        SimulationResult(double legitTime,
                         double attackTime) {
            this.legitTime = legitTime;
            this.attackTime = attackTime;
        }
    }
}