package com.siyagarg.wallet;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.*;

import java.text.DecimalFormat;
import java.util.*;

public class CloudCrypto {

    private static final int TOTAL_CYCLES = 10;
    private static final long BASE_WORKLOAD = 400000;
    private static final int VM_MIPS = 1000;

    private static double totalMined = 0;
    private static double totalHijacked = 0;

    public static void main(String[] args) {

        System.out.println("CRYPTOJACKING SIMULATION\n");

        double baselineTime = CloudInfra(0);

        for (int cycle = 1; cycle <= TOTAL_CYCLES; cycle++) {

            double hijackRate = getHijackRate(cycle);

            double execTime = CloudInfra(hijackRate);

            double degradation =
                    ((execTime - baselineTime) / baselineTime) * 100;

            double mined = attack();
            double hijacked = mined * hijackRate;

            totalMined += mined;
            totalHijacked += hijacked;

            System.out.println("Cycle " + cycle);
            System.out.println("Hijack Rate: " + format(hijackRate * 100) + "%");
            System.out.println("Execution Time: " + format(execTime));
            System.out.println("Performance Degradation: " + format(degradation) + "%");
            System.out.println("Mined: " + format(mined));
            System.out.println("Hijacked: " + format(hijacked));
            System.out.println("------------------------------------");
        }

        double Loss = (totalHijacked / totalMined) * 100;
        System.out.println("Total Loss: " + format(Loss) + "%");
    }

    private static double CloudInfra(double attackIntensity) {

        try {
            CloudSim.init(1, Calendar.getInstance(), false);

            Datacenter dc = createDatacenter("DC");
            DatacenterBroker broker = new DatacenterBroker("Broker");

            int brokerId = broker.getId();

            Vm vm = new Vm(
                    0,
                    brokerId,
                    VM_MIPS,
                    1,
                    512,
                    1000,
                    10000,
                    "Xen",
                    new CloudletSchedulerTimeShared()
            );

            broker.submitVmList(Collections.singletonList(vm));

            List<Cloudlet> cloudletList = new ArrayList<>();

            // Legitimate Task (ID = 0)
            Cloudlet legit = new Cloudlet(
                    0,
                    BASE_WORKLOAD,
                    1,
                    300,
                    300,
                    new UtilizationModelFull(),
                    new UtilizationModelFull(),
                    new UtilizationModelFull()
            );

            legit.setUserId(brokerId);
            legit.setVmId(0);
            cloudletList.add(legit);

            // Attack Task (ID = 1)
            if (attackIntensity > 0) {

                long attackLoad =
                        (long) (BASE_WORKLOAD * attackIntensity);

                Cloudlet attacker = new Cloudlet(
                        1,
                        attackLoad,
                        1,
                        300,
                        300,
                        new UtilizationModelFull(),
                        new UtilizationModelFull(),
                        new UtilizationModelFull()
                );

                attacker.setUserId(brokerId);
                attacker.setVmId(0);
                cloudletList.add(attacker);
            }

            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            // ✅ FIX: Return Legitimate Cloudlet Finish Time
            List<Cloudlet> finishedCloudlets =
                    broker.getCloudletReceivedList();

            for (Cloudlet c : finishedCloudlets) {
                if (c.getCloudletId() == 0) {
                    return c.getFinishTime();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    private static double attack() {
        return 0.02 + (0.06 - 0.02) * Math.random();
    }

    private static double getHijackRate(int cycle) {

        if (cycle < 5)
            return 0;

        double rate = 0.05 * (cycle - 4);
        return Math.min(rate, 0.5);
    }

    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();

        peList.add(new Pe(0,
                new PeProvisionerSimple(VM_MIPS)));

        hostList.add(new Host(
                0,
                new RamProvisionerSimple(2048),
                new BwProvisionerSimple(10000),
                1000000,
                peList,
                new VmSchedulerTimeShared(peList)
        ));

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        "x86",
                        "Linux",
                        "Xen",
                        hostList,
                        10.0,
                        3.0,
                        0.05,
                        0.001,
                        0.0
                );

        try {
            return new Datacenter(
                    name,
                    characteristics,
                    new VmAllocationPolicySimple(hostList),
                    new LinkedList<>(),
                    0
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String format(double value) {
        return new DecimalFormat("0.000").format(value);
    }
}
